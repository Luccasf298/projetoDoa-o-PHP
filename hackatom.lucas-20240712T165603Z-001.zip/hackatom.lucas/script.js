document.addEventListener("DOMContentLoaded", function() {
    // Aqui você pode adicionar scripts para interatividade
});
